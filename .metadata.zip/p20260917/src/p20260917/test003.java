package p20260917;

import java.util.Scanner;

public class test003 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		
		System.out.println("숫자 입력(0 입력 시 종료): ");
		int num = sc.nextInt();
		while(num != 0) {
			sum = sum+num;
			System.out.println("현재 합계: "+ sum);
			

			System.out.println("숫자 입력(0 입력 시 종료): ");
			num = sc.nextInt();
		}
		System.out.println("최종 합계는: "+ sum + "입니다.");
		sc.close();
	}

}
