package p20260917;

public class test004 {

	public static void main(String[] args) {
		for(int dan=2; dan<=9; dan++) {
			System.out.println("\n"+dan+"단: ");
			
			for(int num=1; num<=9; num++) {
				System.out.println(dan+"x"+num+"="+(dan*num)+", ");
			}
		}
	}

}
