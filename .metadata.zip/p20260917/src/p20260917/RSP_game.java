package p20260917;

import java.util.Random;
import java.util.Scanner;

public class RSP_game {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Random rd = new Random();
		
		System.out.println("가위(0), 바위(1), 보(2) 중 선택: ");
		int game = sc.nextInt();
		int num = rd.nextInt(3);
		
		System.out.println("컴퓨터의 선택: " + num);
		
		if(game == num) {
			System.out.println("비김");
		}
		else if((game == 0 && num == 1) || (game == 1 && num == 2) || (game == 2 && num == 0)) {
			System.out.println("컴퓨터 승!");
		}
		else if((game == 1 && num == 0) || (game == 2 && num == 1) || (game == 0 && num == 2)) {
			System.out.println("인간 승!");
		}
		else {
			System.out.println("다시 입력하세요.");
		}
//		switch(game) {
//			case 0:
//				switch(num) {
//					case 0:
//						System.out.println("비김");
//						break;
//					case 1:
//						System.out.println("컴퓨터 승!");
//						break;
//					case 2:
//						System.out.println("인간 승!");
//						break;
//					default:
//						System.out.println("다시 써주세요(1 ~ 2)");
//				}
//			case 1:
//				switch(num) {
//					case 0:
//						System.out.println("인간 승!");
//						break;
//					case 1:
//						System.out.println("비김");
//						break;
//					case 2:
//						System.out.println("컴퓨터 승!");
//						break;
//					default:
//						System.out.println("다시 써주세요(1 ~ 2)");
//				}
//			case 2:
//				switch(num) {
//					case 0:
//						System.out.println("컴퓨터 승!");
//						break;
//					case 1:
//						System.out.println("인간 승!");
//						break;
//					case 2:
//						System.out.println("비김");
//						break;
//					default:
//						System.out.println("다시 써주세요(1 ~ 2)");
//				}
//		}
		sc.close();
	}

}
