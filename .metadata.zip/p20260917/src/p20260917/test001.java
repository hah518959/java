package p20260917;

import java.util.Scanner;

public class test001 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("주문입력: ");
		int menu = sc.nextInt();
		
		switch(menu) {
			case 1:
				System.out.println("크림 도넛");
				break;
			case 2:
				System.out.println("딸기 도넛");
				break;
			case 3:
				System.out.println("너트 도넛");
				break;
			 default:
				System.out.println("없는 메뉴입니다.");
		}
		sc.close();
	}

}
