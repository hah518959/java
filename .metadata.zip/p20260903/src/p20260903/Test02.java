package p20260903;

public class Test02 {

	public static void main(String[] args) {
//		final int MAX_BOX = 4;		
//		System.out.println("박스크기:"+MAX_BOX);
		
		
		
	}

}
