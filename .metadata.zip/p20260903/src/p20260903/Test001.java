package p20260903;

public class Test001 {

	public static void main(String[] args) {
		int price = 2000, sale = 1500;
		
//		System.out.println(price+ "," + sale);
//		price = sale;
//		System.out.println(price+ "," + sale);
		
		System.out.println(1+2+3);
		System.out.println(1+"합계구하기"+2+3);
		
	}

}
