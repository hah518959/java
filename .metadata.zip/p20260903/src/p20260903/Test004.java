package p20260903;

import java.util.Scanner;

public class Test004 {

	public static void main(String[] args) {
		Scanner sin = new Scanner(System.in);
		
		System.out.println("정수 입력: ");
		int price = sin.nextInt();
		System.out.printf("입력 값: %d", price);
	}

}
