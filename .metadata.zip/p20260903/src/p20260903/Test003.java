package p20260903;

public class Test003 {

	public static void main(String[] args) {
		long longprice = 25l;
		int octal = 031;
		int hex = 0x19;
		int binary = 0b11001;
		double standardFloat = 25.75;
		double exponential = 2.575e1;
		float lowFloat = 25.75F;
		
		System.out.println(longprice+ "," + octal + "," + hex + "," + binary + "," + standardFloat+ "," +exponential+ "," +lowFloat);
	}

}
