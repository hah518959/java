package p261008;

class ms{
	private String model;
	private int speed;
	ms(String model){ //생성자
		this.model=model;
		this.speed=0;
	}
	
	void Accelerate() {
		speed = speed + 10;
		System.out.println("현재 "+model+"의 속도: "+speed);
	}
	void Break() {
		speed = speed - 10;
		System.out.println("현재 "+model+"의 속도: "+speed);
	}
}

class Car{
	public static void main(String[] args){
		ms car1 = new ms("햄버거");
		ms car2 = new ms("김치");
		
		car1.Accelerate();
		car1.Accelerate();
		car2.Break();
		car2.Accelerate();
		car1.Accelerate();
	}
}