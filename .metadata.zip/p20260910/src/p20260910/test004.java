package p20260910;
import java.util.Scanner;
public class test004 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("첫 번째 값 입력: ");
		double num1=sc.nextDouble();
		System.out.print("두 번째 값 입력: ");
		double num2=sc.nextDouble();
		
		double sum = num1 + num2;
		double sub = num1 - num2;
		double product = num1 * num2;
		double div = num1 / num2;
		
		System.out.println("덧셈: "+ sum);
		System.out.println("뺄셈: "+ sub);
		System.out.println("곱셈: "+ product);
		System.out.println("나눗셈: "+ div);
		
		sc.close();
	}

}
