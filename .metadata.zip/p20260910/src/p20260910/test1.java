package p20260910;

public class test1 {

	public static void main(String[] args) {
		int a=10, b=3;
		
		System.out.println("-a= "+ -a);
		System.out.println("a+b= "+ (a+b));
		System.out.println("a-b= "+ (a-b));
		System.out.println("a*b= "+ (a*b));
		System.out.println("a/b= "+ (a/b));
		System.out.println("a%b= "+ (a%b));
		
	}

}
