package p20260910;

public class test002 {
	public static void main(String[] args) {
		int a=5, b=5;
	
		System.out.println("++a= "+ ++a);
		System.out.println("b++= "+ b++ +"끝난 후: "+ b);
	}
}