package p20261001;

public class test002 {

	public static void main(String[] args) {
		//String[] donutBox = {"제로", "기본", "크림", "초코", "딸기"};
		String[][] donutBox = {
				{"기본", "크림", "초코"},
				{"크런치", "망고", "생딸기"}
		};
		
		
		
		for(int i=0; i < donutBox.length; i++) {
			for(int j=0; j < donutBox[i].length; j++) {
				System.out.println("도넛["+i+"]["+j+"]="+donutBox[i][j]);
			}
		}
	}

}
