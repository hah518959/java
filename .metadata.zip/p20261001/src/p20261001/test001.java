package p20261001;

public class test001 {

	public static void main(String[] args) {
		int[] price = {2000, 2300, 2700, 3000, 3500};
		int sum = 0;
		
		for(int i=0; i < 5; i++) {
			System.out.println("도넛" + i+": "+price[i]+"원");
			sum = sum + price[i];
		}
		System.out.println("총 도넛 가격: "+ sum + "원");
	}

}
