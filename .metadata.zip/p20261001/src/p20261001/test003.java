package p20261001;

public class test003 {

	public static void main(String[] args) {
		int[][] gugudan = new int[8][9];
		
		for(int i = 0; i< gugudan.length; i++) {
			for(int j = 0; j< gugudan[i].length; j++) {
				gugudan[i][j] = (i+2)*(j+1);
				System.out.println("gugudan["+i+"]["+j+"]="+(i+2)+" * "+(j+1)+" = "+gugudan[i][j]);
			}
		}
	}
}
