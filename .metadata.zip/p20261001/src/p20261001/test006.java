package p20261001;

public class test006 {

	public static void main(String[] args) {
		char[][] star = new char[5][5];
		for(int i=0; i<star.length; i++) {
			for(int j=0; j<=i; j++) {
				star[i][j] = '*';
			}
		}
		for(int i=0; i<star.length; i++) {
			for(int j=0; j < star[i].length; j++) {
				if(star[i][j] == '*') {
					System.out.println(star[i][j]);
				}
				else {
					System.out.println(" ");
				}

			}
		}
}
}