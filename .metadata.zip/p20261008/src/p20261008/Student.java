package p20261008;

class Test{
	private String name;
	Test(String name){ //생성자
		this.name=name;
	}
	
	void introduce() {
		System.out.println("저는 "+name+"입니다.");
	}
}

public class Student{
	public static void main(String[] args){
		Test st = new Test("홍길동"); //Test 클래스를 객체로 만들기
		
//		st.name="홍길동";
		
		
		st.introduce();
		
	}
}