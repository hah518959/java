package p20261008;

class car_specific{
	private String car_name;
	car_specific (String car_name){
		this.car_name = car_name;
	}
	
	void specific() {
		System.out.println("자동차 이름은 "+car_name+"입니다.");
	}
}

public class Car{
	public static void main(String[] args){
		car_specific st = new car_specific("EV5");		
		
		st.specific();
		
	}
}