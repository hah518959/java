package p20260910;
public class test001 {

	public static void main(String[] args) {
		int a=10, b=3;
		
		System.out.println()
	}

}
