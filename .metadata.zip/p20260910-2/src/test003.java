
public class test003 {

	public static void main(String[] args) {
		int x=10, y=20;
		int max=(x>y)?x:y;
		
		System.out.println(max);
	}

}
