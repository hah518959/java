import java.util.Scanner;

public class test002 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("쿠폰 수 입력: ");
		int coupon=sc.nextInt();
		
		if (coupon>=10) {
			System.out.println("도넛 4개 무료");
		}
		else if (coupon>=3){
			System.out.println("무료 음료");
		}
		else{
			System.out.println("다음 기회에");
		}
		
		sc.close();
	}

}
