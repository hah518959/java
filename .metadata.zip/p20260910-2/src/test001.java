
public class test001 {

	public static void main(String[] args) {
		int price = 25000;
		
		if(price>=26000) {
			System.out.println("쿠폰 1장");
		}
		else {
			System.out.println("쿠폰 없음");
		}
		System.out.println("또 방문해 주세요");
	}

}
