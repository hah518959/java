package javates0827;

public class Test001 {

	public static void main(String[] args) {
		System.out.println("안녕하세요");
		System.out.println(12345);
		/* System.out.println("안녕하세요"+000); */
		System.out.println(67890);
		System.out.println("안녕하세요"+1+2+3);
	}

}
